﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
for (int i = 0; i < 3; i++)
{
    if (i == 2)
    {
        throw new Exception($"This is an exception because {i} == 2");
    }
}
